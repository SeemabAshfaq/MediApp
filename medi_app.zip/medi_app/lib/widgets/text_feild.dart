 import 'package:flutter/material.dart';
import 'package:medi_app/constants/colors.dart';
import 'package:medi_app/constants/strings.dart';
import 'package:velocity_x/velocity_x.dart';

class CustomTextFeild extends StatefulWidget {
     final String hint;
   final TextEditingController? textController;
   final Color boderColor;
   final Color textColor;
   final Color hintColor;
    final Color enteredTextColor; // Added parameter for the entered text color
  const CustomTextFeild({super.key,required this.hint,this.textController,required this.textColor, required this.boderColor, required this.hintColor, required this.enteredTextColor});

  @override
  State<CustomTextFeild> createState() => _CustomTextFeildState();
}

class _CustomTextFeildState extends State<CustomTextFeild> {
  @override
  Widget build(BuildContext context) {
    return  
                TextFormField(
                  controller: widget.textController,
                  cursorColor: AppColors.blueColor,
                   style: TextStyle(color: widget.enteredTextColor),
                   decoration: InputDecoration(
                    isDense: true,
                    focusedBorder: OutlineInputBorder(
                      borderSide: BorderSide(
                        color: widget.boderColor
                      )
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(
                        color: widget.boderColor
                      )
                    ),
                    border: OutlineInputBorder(
                  borderSide: BorderSide(
                    color: 
                    widget.boderColor
                  )
                    ),
                    hintText: widget.hint,
                    hintStyle: TextStyle(color: widget.hintColor)
                   ),
                );
  }
}