import 'package:flutter/material.dart';
import 'package:medi_app/constants/colors.dart';
import 'package:medi_app/constants/strings.dart';
import 'package:velocity_x/velocity_x.dart';

class CustomButton extends StatelessWidget {
  final  Function()? onTap;
  final String buttonText;
  const CustomButton({super.key,required this.buttonText,required this.onTap});

  @override
  Widget build(BuildContext context) {
    return  SizedBox(
                  width: double.infinity,
                  height: 44,
                  child: ElevatedButton(
                    
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.primaryColor,
                    shape: const StadiumBorder()
                  ),
                    onPressed: onTap, child: Text(buttonText,style: TextStyle(
                      color: AppColors.white
                    ),),
                    ));
  }
}