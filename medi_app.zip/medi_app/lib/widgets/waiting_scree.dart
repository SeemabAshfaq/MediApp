import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:medi_app/controllers/auth_controller.dart';
import 'package:medi_app/views/homeView/home.dart';
import 'package:medi_app/views/loginView/login_view.dart';

class WaitingScreen extends StatefulWidget {
  const WaitingScreen({Key? key}) : super(key: key);

  @override
  State<WaitingScreen> createState() => _WaitingScreenState();
}

class _WaitingScreenState extends State<WaitingScreen> {
  late AuthController _authController;

  @override
  void initState() {
    _authController = AuthController();
    _checkAuthState();
    super.initState();
  }

  _checkAuthState() async {
    bool isLoggedIn = await _authController.isUserAlreadyLogIn();
    if (isLoggedIn) {
      Get.offAll(() => Home());
    } else {
      Get.offAll(() => LoginView());
    }
  }

  @override
  Widget build(BuildContext context) {
    return Center(
      child: CircularProgressIndicator(),
    );
  }
}
