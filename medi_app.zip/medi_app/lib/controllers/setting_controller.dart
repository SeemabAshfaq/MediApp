import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:get/get.dart';
import 'package:get/get_state_manager/get_state_manager.dart';

class SettingsController extends GetxController {
  var isLoading = false.obs;
  var userName = ''.obs;
  var email = ''.obs;

  @override
  void onInit() {
    super.onInit();
    getData();
  }

  getData() async {
    isLoading(true);
    var user = FirebaseAuth.instance.currentUser;
    if (user != null) {
      DocumentSnapshot<Map<String, dynamic>> userData = await FirebaseFirestore.instance.collection('users').doc(user.uid).get();
      var userDataMap = userData.data();
      if (userDataMap != null) {
        userName.value = userDataMap['fullname'] ?? "";
        email.value = user.email ?? '';
      }
    }
    isLoading(false);
  }
}
