import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:get/get_navigation/get_navigation.dart';
import 'package:get/get_state_manager/get_state_manager.dart';
import 'package:medi_app/views/homeView/home.dart';
import 'package:medi_app/views/loginView/login_view.dart';

class AuthController extends GetxController{
  var fullNameController= TextEditingController();
  var passController =TextEditingController();
  var emailController= TextEditingController();

   var aboutController= TextEditingController();
  var adressController =TextEditingController();
  var serviceController= TextEditingController();
   var timingController= TextEditingController();
  var phoneController =TextEditingController();
  var categoryController= TextEditingController();
  UserCredential? userCredential;



isUserAlreadyLogIn() async{

 // var data= await FirebaseFirestore.instance.collection('doctors').doc(curr)
     User? user = FirebaseAuth.instance.currentUser;
    return user != null;
}


  logInUser() async {
  
    userCredential= await FirebaseAuth.instance.signInWithEmailAndPassword(email: emailController.text, password: passController.text);
    }

  signupUser(bool isDoctor) async {
  
    userCredential= await FirebaseAuth.instance.createUserWithEmailAndPassword(email: emailController.text, password: passController.text);
    await storeUserData(userCredential!.user!.uid,fullNameController.text,emailController.text,isDoctor);
  }

  storeUserData(String uid ,String fullName,String  email,bool isDoctor) async {
    var store= FirebaseFirestore.instance.collection(isDoctor?"doctors": "users").doc(uid);
    if(isDoctor){
      await store.set(
{
  'docAbour':aboutController.text,
  'docAdress': adressController.text,
  'docCategory':categoryController.text,
  'doc_name': fullName,
  'docPhone' : phoneController.text,
  'docService':serviceController.text,
  'docTiming': timingController.text,
  'docId':FirebaseAuth.instance.currentUser?.uid,
  'docRatting':1,
  'docEmail':email,

}
        
      );
    }
    else{
       await store.set({'fullname': fullName,'email':email});
    }
   
  }


signOut()async {
  await FirebaseAuth.instance.signOut();
}
}