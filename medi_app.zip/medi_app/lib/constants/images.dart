// class AppAssets{
//   static String icBody ="assets/icons/ic_body.png"
// }