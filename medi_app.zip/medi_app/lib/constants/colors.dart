import 'package:flutter/material.dart';

class AppColors{
  static Color primaryColor= const Color(0xff2A7FBA),
  yellowColor = const Color(0xffFF9f00),
  bgColor = const Color(0xffF5F5F5),
  bgDarkColor = const Color(0xffECECEC),
  white = Colors.white,
  greenColor =  Colors.green,
  blueColor=Colors.blue,
  textColor = Colors.black;
}