import 'package:flutter/material.dart';
import 'package:medi_app/constants/strings.dart';

var iconsTitleList=[
AppStrings.body,
AppStrings.ear,
AppStrings.liver,
AppStrings.lungs,
AppStrings.heart,
AppStrings.kidney,

];

var specialistList=[
AppStrings.s13,
AppStrings.s16,
AppStrings.s18,
AppStrings.s20,
AppStrings.s10,
AppStrings.s22,

];

var settingsList=[
  AppStrings.chnagePassword,
  AppStrings.termsAnadConditions,
  AppStrings.signOut,
];

var settingsIconsList=[
 Icons.lock,
 Icons.note,
 Icons.logout
];