class AppStrings{
  static String appName="Mediapp",
  bestDocapp ="Best Doctor\n Appointment App",
  welcomeBack ="welcome Back!",
  weAreExcited ="We're excited to have you back!",
 signupNow ="SignUp now and start exploring  all that our\napp has to offer.",
 email ="Email",
 emailHint ="Enter your email...",
 password ="Password",
 chnagePassword="Change Password",
 termsAnadConditions="Terms and Conditions",
 signOut="SignOut",
 passwordHint ="Enter your password here...",
 fullanme ="Full Name",
 fullnameHint ="Enter your full name here...",
confirmPassword ="Confirm Password",
login ="Login",
s13="13 specialists",
s16="16 specialists",
s18="18 specialists",
s20="20 specialists",
s22="22 specialists",
s10="10 specialists",
doctor = "Doctor Login",
settings ="Settings",
signup ="Signup",
alreadyHaveAccount = "Account have an Account?",
dontHaveAccount ="Don't have an Account?",
welcome="Welcome",
search="Search doctor",
body = "Body",
category = "Category",
ear ="Ear",
liver ="Liver",
lungs="Lungs",
heart="Heart",
kidney="Kidney",
  forgetPassword ="Forget Password?";


  
  
  
}