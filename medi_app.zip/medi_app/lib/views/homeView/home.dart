import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:medi_app/constants/colors.dart';
import 'package:medi_app/views/appointmentView/appointment_view.dart';
import 'package:medi_app/views/categoryView/category_view.dart';
import 'package:medi_app/views/doctorProfileView/doctor_profil_view.dart';
import 'package:medi_app/views/homeView/home_view.dart';
import 'package:medi_app/views/loginView/login_view.dart';
import 'package:medi_app/views/settingsView/settings_view.dart';

class Home extends StatefulWidget {
  const Home({super.key});

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  int selectedIndex=0;
  List screensList=[
   const  HomeView(),
  const AppointmentView(),
   const CategoryView(),
const SettingsView(),
  ];
  @override
  Widget build(BuildContext context) {
    return  Scaffold(
          body: screensList.elementAt(selectedIndex),
      bottomNavigationBar: BottomNavigationBar(
        backgroundColor: AppColors.blueColor,
        selectedLabelStyle: TextStyle(color: AppColors.white),
        unselectedItemColor: AppColors.white.withOpacity(0.4),
        selectedItemColor: AppColors.white,
        selectedIconTheme: IconThemeData(
         color: AppColors.white,
        ),
        type: BottomNavigationBarType.fixed,
        currentIndex: selectedIndex,
        onTap: (value){
           setState(() {
             selectedIndex=value;
           });
        },
        items: const [
        BottomNavigationBarItem(icon:Icon(Icons.home,),label:"Home" ),
         BottomNavigationBarItem(icon:Icon(Icons.book,),label:"Book Appointments" ),
          BottomNavigationBarItem(icon:Icon(Icons.category),label:"Feild"),
        
            BottomNavigationBarItem(icon:Icon(Icons.settings),label:"Settings"),
      ],),
    );
  }
}