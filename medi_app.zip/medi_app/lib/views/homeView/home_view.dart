import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:get/get_navigation/get_navigation.dart';
import 'package:medi_app/constants/colors.dart';
import 'package:medi_app/constants/fonts.dart';
import 'package:medi_app/constants/list.dart';
import 'package:medi_app/constants/strings.dart';
import 'package:medi_app/controllers/home_controller.dart';
import 'package:medi_app/views/categoryDetailView/category_detail_view.dart';
import 'package:medi_app/views/doctorProfileView/doctor_profil_view.dart';
import 'package:medi_app/views/searchView/search_view.dart';
import 'package:medi_app/widgets/text_feild.dart';

class HomeView extends StatelessWidget {
  
  const HomeView({super.key,});

  @override
  Widget build(BuildContext context) {
    var controller = Get.put(HomeController());
    return Scaffold(
      //resizeToAvoidBottomInset: false,
      appBar: AppBar(
        elevation: 0.0,
        backgroundColor: AppColors.blueColor,
        iconTheme: IconThemeData(color: AppColors.white),
        title: AppStyles.bold(
          title: "${AppStrings.welcome} Users",
          color: AppColors.white,
          size: AppSizes.size18,
        ),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            GestureDetector(
              onTap: (){},
              child: Container(
                padding: EdgeInsets.all(10.h),
                height: 100.h,
                color: AppColors.blueColor,
                child: Row(
                  children: [
                    Expanded(
                      child: CustomTextFeild(
                        textController: controller.searchQueryController,
                        enteredTextColor: AppColors.white,
                        hintColor: AppColors.white,
                        textColor: AppColors.white,
                        boderColor: AppColors.white,
                        hint: AppStrings.search, 
                      ),
                    ),
                    SizedBox(width: 5.w),
                    IconButton(
                      onPressed: () {
                        Get.to(()=>SearchView(searchQuery:controller.searchQueryController.text));
                      },
                      icon: Icon(Icons.search, color: AppColors.white),
                    ),
                  ],
                ),
              ),
            ),
            SizedBox(height: 20.h),
            Padding(
              padding:  EdgeInsets.all(30.h),
              child: SizedBox(
                height: 100.h,
                child: ListView.builder(
                  physics: const BouncingScrollPhysics(),
                  scrollDirection: Axis.horizontal,
                  itemCount: 6,
                  itemBuilder: (context, index) {
                    return GestureDetector(
                      onTap: (){
                        Get.to(()=>CategoryDetailsView(catName: iconsTitleList[index]));
                      },
                      child: Container(
                        width: 60.w,
                        margin:EdgeInsets.only(right: 20.w),
                        height: 50.h,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(8.h),
                          color: AppColors.blueColor,
                        ),
                        
                       child: Column(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          
                          Icon(Icons.person_2_outlined,color: AppColors.white,size: 50.h,),
                          AppStyles.normal(
                            title:iconsTitleList[index],
                             color: AppColors.white
                          )
                        ],
                       ),
                      ),
                    );
                  },
                ),
              ),
              
            ),
              //SizedBox(height: 20.h,),
         Padding(
           padding: EdgeInsets.only(left:25.w),
           child: Align(
            alignment: Alignment.centerLeft,
            child:    AppStyles.bold(title: "Popular Doctors",color: AppColors.blueColor,size: AppSizes.size18),
           ),
         ),
            SizedBox(height: 20.h,),
            Padding(
             padding: EdgeInsets.only(left:25.w),
              child: FutureBuilder(
                future: controller.getDoctorList(),
               builder: (BuildContext context,AsyncSnapshot<QuerySnapshot> snapshot){
                    if(!snapshot.hasData){
                      return Center(
                        child: CircularProgressIndicator(),
                      );
                    }
                    else{
                      var data=snapshot.data?.docs;
                      return SizedBox(
                height: 150.h,
                child: ListView.builder(
                   physics: const BouncingScrollPhysics(),
                  scrollDirection: Axis.horizontal,
                  itemCount: data?.length??0,
                  itemBuilder: (context,index){
                  return GestureDetector(
                    onTap: (){
                      Get.to(()=> DoctorProfileView(doc: data[index],));
                    },
                    child: Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(12.w)
                      ),
                      margin: EdgeInsets.only(right: 8.w),
                      // color: Colors.red,
                      height: 100.h,
                      width: 150.w,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          Container(
                              decoration: BoxDecoration(
                       borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(12.w),
                      topRight: Radius.circular(12.w),
                    ),
                         color: AppColors.blueColor,
                      ),
                            width: double.infinity,
                           
                            child: ClipRRect
                            (
                                
                         borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(12.w),
                      topRight: Radius.circular(12.w),
                    ),
                      
                              
                              child: Image.asset("assets/images/doctor1.png",height: 100.h,fit: BoxFit.cover,))),
                          AppStyles.normal(title: data![index]['doc_name']),
                             AppStyles.normal(title: data![index]['docCategory'],color: AppColors.textColor)
                                
                        ],
                      ),
                    ),
                  );
                }),
              );
                    }
        
               })
            ),
          Align(
            alignment: Alignment.centerRight,
            child: GestureDetector(
              onTap: (){
        
              },
              child: AppStyles.bold(title: "View All",color: AppColors.blueColor,size: AppSizes.size18),
            ),
            
          ),
          SizedBox(height: 15.h,),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: List.generate(
            4,
            (index) => Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12.h),
          color: AppColors.blueColor,
        ),
        padding: EdgeInsets.all(12.h),
        
        height: 100.h,
             // width: 100.w,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            Icon(Icons.person,color: AppColors.white,),
            AppStyles.normal(title: "Lab Test",color: AppColors.white),
          ],
        ),
            ),
          ),
        )
          ],
        ),
      ),
    );
  }
}
