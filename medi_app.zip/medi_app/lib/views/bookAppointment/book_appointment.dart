import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:get/get_navigation/get_navigation.dart';
import 'package:medi_app/constants/colors.dart';
import 'package:medi_app/constants/fonts.dart';
import 'package:medi_app/constants/strings.dart';
import 'package:medi_app/controllers/appointment_controller.dart';
import 'package:medi_app/widgets/custom_button.dart';
import 'package:medi_app/widgets/text_feild.dart';

class BookAppointment extends StatelessWidget {
  final String docId;
  final String docName;
   BookAppointment({super.key,required this.docId,required this.docName});

  @override
  Widget build(BuildContext context) {
    var  controller=Get.put(AppointmentController());
    return  Scaffold(
      appBar: AppBar(
            elevation: 0.0,
        backgroundColor: AppColors.blueColor,
        iconTheme: IconThemeData(color: AppColors.white),
     title: AppStyles.bold( 
        title: docName,size: AppSizes.size18,color: AppColors.white,
     ),
  ),
  body: Padding(
    padding:  EdgeInsets.all(12.h),
    child: SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          AppStyles.bold(title: "Select Appointment Day"),
         CustomTextFeild(
          textController: controller.appDayController,
          hint: "Select Day", textColor: AppColors.textColor, boderColor: AppColors.textColor.withOpacity(0.5), hintColor: AppColors.textColor.withOpacity(0.5), enteredTextColor: AppColors.textColor),
         SizedBox(height: 10.h,),
      
          AppStyles.bold(title: "Select Appointment Time"),
         CustomTextFeild(
          textController: controller.appTimeController,
          hint: "Select Time", textColor: AppColors.textColor, boderColor: AppColors.textColor.withOpacity(0.5), hintColor: AppColors.textColor.withOpacity(0.5), enteredTextColor: AppColors.textColor),
       
          SizedBox(height: 10.h,),
      
          AppStyles.bold(title: "Enter Your Contact Number"),
         CustomTextFeild(
          textController: controller.appMobileController,
          hint: "Contact Number", textColor: AppColors.textColor, boderColor: AppColors.textColor.withOpacity(0.5), hintColor: AppColors.textColor.withOpacity(0.5), enteredTextColor: AppColors.textColor),
      
      
          SizedBox(height: 10.h,),
      
          AppStyles.bold(title: "Enter Your Full Name"),
         CustomTextFeild(
          textController: controller.appNameController,
          hint: "Full Name", textColor: AppColors.textColor, boderColor: AppColors.textColor.withOpacity(0.5), hintColor: AppColors.textColor.withOpacity(0.5), enteredTextColor: AppColors.textColor),
         
      
          SizedBox(height: 10.h,),
      
          AppStyles.bold(title: "Write Message"),
         CustomTextFeild(
          textController: controller.appMessageController,
          hint: "Message", textColor: AppColors.textColor, boderColor: AppColors.textColor.withOpacity(0.5), hintColor: AppColors.textColor.withOpacity(0.5), enteredTextColor: AppColors.textColor),
        ],
      ),
    ),
  ),
   bottomNavigationBar: Obx(
     ()=> Padding(
      padding:  EdgeInsets.all(12.h),
      child: 
      controller.isLoading.value?Center(
        child: CircularProgressIndicator(),
      ):
      CustomButton(buttonText: "Book an Appointment", onTap: ()async{
        //Get.to(AppointmentView());
      await  controller.BookAppointment(docId, context,docName);
      }),
       ),
   ), 
    );
  }
}