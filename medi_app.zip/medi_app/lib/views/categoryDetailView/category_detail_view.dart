import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:medi_app/constants/colors.dart';
import 'package:medi_app/constants/fonts.dart';
import 'package:medi_app/constants/strings.dart';
import 'package:medi_app/views/doctorProfileView/doctor_profil_view.dart';
import 'package:velocity_x/velocity_x.dart';

class CategoryDetailsView extends StatelessWidget {
  final String catName;
  const CategoryDetailsView({super.key,required this.catName});

  @override
  Widget build(BuildContext context) {

    return  Scaffold(
      backgroundColor: const Color.fromARGB(255, 243, 237, 237),
       appBar: AppBar(
        elevation: 0.0,
        backgroundColor: AppColors.blueColor,
        iconTheme: IconThemeData(color: AppColors.white),
        title: AppStyles.bold(
          title: catName,
          color: AppColors.white,
          size: AppSizes.size18,
        ),
        
      ),
      body: FutureBuilder<QuerySnapshot>
      (
        future: FirebaseFirestore.instance.collection('doctors').where('docCategory',isEqualTo: catName).get(),
       builder: (BuildContext context, AsyncSnapshot<QuerySnapshot>snapshot){
        if(!snapshot.hasData){
          return Center(
            child: CircularProgressIndicator(),
          );
        }
        else{
          var data=snapshot.data?.docs;
          return Padding(
        padding:  EdgeInsets.all(12.h),
        child: GridView.builder(gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          mainAxisSpacing: 8,
          crossAxisSpacing: 8,
          mainAxisExtent: 170
          ),
          
          itemCount:data?.length??0,
          itemBuilder: (BuildContext context, int index){
            return Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(12.w),
                        color: AppColors.white
                      ),
                      margin: EdgeInsets.only(right: 8.w),
                      // color: Colors.red,
                      // height: 100.h,
                      // width: 150.w,
                      child: Padding(
                        padding: EdgeInsets.all(8.h),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            Container(
                                decoration: BoxDecoration(
                         borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(12.w),
                        topRight: Radius.circular(12.w),
                                            ),
                           color: AppColors.blueColor,
                        ),
                              width: double.infinity,
                             
                              child: ClipRRect
                              (
                                  
                           borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(12.w),
                        topRight: Radius.circular(12.w),
                                            ),
                        
                                
                                child: Image.asset("assets/images/doctor1.png",height: 100.h,fit: BoxFit.cover,))),
                            
                               AppStyles.normal(title:data![index]['doc_name'],color: AppColors.textColor),
                                VxRating(onRatingUpdate: (value){},
                    selectionColor: Colors.yellow,
                    maxRating: 5,
                    count: 5,
                    value: double.parse(data[index]['docRatting'].toString()),
                    stepInt: true,)
                                  
                          ],
                        ),
                      ),
                    ).onTap(() {
                      Get.to(()=>DoctorProfileView(doc: data[index]));
                    });
          },
          ),
      );
        }
       })
    );
  }
}