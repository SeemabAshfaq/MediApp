import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:get/get_instance/get_instance.dart';
import 'package:get/get_navigation/get_navigation.dart';
import 'package:medi_app/constants/colors.dart';
import 'package:medi_app/constants/fonts.dart';
import 'package:medi_app/constants/strings.dart';
import 'package:medi_app/controllers/auth_controller.dart';
import 'package:medi_app/views/appointmentView/appointment_view.dart';
import 'package:medi_app/views/homeView/home.dart';
import 'package:medi_app/views/signupView/signup_view.dart';
import 'package:medi_app/widgets/custom_button.dart';
import 'package:medi_app/widgets/text_feild.dart';
import 'package:velocity_x/velocity_x.dart';


class LoginView extends StatefulWidget{
  const LoginView({super.key});

  @override
  State<LoginView> createState() => _LoginViewState();
}

class _LoginViewState extends State<LoginView> {
var isDoctor= false;
     @override

  Widget build(BuildContext context) {
     var controller= Get.put(AuthController());
    return Scaffold(
      body: Padding(
        padding:  EdgeInsets.all(8.h),
        child: SingleChildScrollView(
          child: Column(
            children: [
              SizedBox(
                height: 300.h,
                width: double.infinity,
                child: 
              Image.asset("assets/images/doctor.jpg",fit: BoxFit.cover,),
              ),
           Form(
                  child:
               Column(
                 children: [
                   SizedBox(height: 20.h,),
                   
                   CustomTextFeild(
                    textController: controller.emailController,
                    enteredTextColor: AppColors.textColor,
                     hintColor: AppColors.textColor,
                    textColor: AppColors.textColor,
                    boderColor:  AppColors.textColor,
                    hint: AppStrings.email,
                   ),
                SizedBox(height: 10.h,),
                    CustomTextFeild(
                      textController: controller.passController,
                      enteredTextColor: AppColors.textColor,
                       hintColor: AppColors.textColor,
                       textColor: AppColors.textColor,
                    boderColor:  AppColors.textColor,
                hint: AppStrings.password,
               ),
                SizedBox(height: 10.h,),
                SwitchListTile(value: isDoctor, onChanged: (newValue)
                {
                  setState(() {
                    isDoctor=newValue;
                  });
                },title: "Sign in as a doctor".text.make(),),
               SizedBox(height: 20.h,),
               Align(
                alignment: Alignment.centerRight,
                child: AppStrings.forgetPassword.text.make()),
          
                SizedBox(height: 20.h,),
          
               CustomButton(
                onTap: () async{
                 await  controller.logInUser();
                 if(controller.userCredential!=null){
                  if(isDoctor){
                     Get.to(()=> const AppointmentView());
                  }
                  else{
                     Get.to(()=> const Home());
                  }
                 }
                
                },
                buttonText: AppStrings.login,
               ),
          
               SizedBox(height: 20.h,),
          
               Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  AppStrings.dontHaveAccount.text.make(),
                  SizedBox(width: 8.w,),
              GestureDetector(
                onTap: (){
                  Get.to(()=> const SignUpView());
                },
                child:     AppStyles.bold(title:AppStrings.signup,alignment: TextAlign.center),
              )
                ],
               )
                 ],
               ),
          
               
                ),
              
            ],
          ),
        ),
      ),
    );
  }
}