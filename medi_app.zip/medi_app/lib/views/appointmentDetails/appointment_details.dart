import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:medi_app/constants/colors.dart';
import 'package:medi_app/constants/fonts.dart';
import 'package:medi_app/widgets/text_feild.dart';

class AppointmentDetailsView extends StatelessWidget {
  final DocumentSnapshot doc;
  const AppointmentDetailsView({super.key,required this.doc});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
       appBar:  AppBar(
            elevation: 0.0,
        backgroundColor: AppColors.blueColor,
        iconTheme: IconThemeData(color: AppColors.white),
     title: AppStyles.bold(
        title:doc['appWithName'],size: AppSizes.size18,color: AppColors.white,
     ),
  ),
  body: Padding(
    padding:  EdgeInsets.all(12.h),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
          AppStyles.bold(title: "Select Appointment Day"),
           AppStyles.normal(title: doc['appDay']),
          
           SizedBox(height: 10.h,),
        
            AppStyles.bold(title: "Select Appointment Time"),
             AppStyles.normal(title: doc['appTime']),
          
         
            SizedBox(height: 10.h,),
        
            AppStyles.bold(title: "Contact Number"),
             AppStyles.normal(title: doc['appMobile']),
           
        
        
            SizedBox(height: 10.h,),
        
            AppStyles.bold(title: "Full Name"),
             AppStyles.normal(title:doc['appName']),
          
           
        
            SizedBox(height: 10.h,),
        
            AppStyles.bold(title: "Message"),
             AppStyles.normal(title: doc['appMsg']),
      ]
    ),
  ),

    );
  }
}