import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:get/get_navigation/get_navigation.dart';
import 'package:medi_app/constants/colors.dart';
import 'package:medi_app/constants/fonts.dart';
import 'package:medi_app/constants/strings.dart';
import 'package:medi_app/controllers/appointment_controller.dart';
import 'package:medi_app/views/bookAppointment/book_appointment.dart';
import 'package:medi_app/widgets/custom_button.dart';
import 'package:velocity_x/velocity_x.dart';

class DoctorProfileView extends StatelessWidget {
  final DocumentSnapshot doc;
  const DoctorProfileView({super.key,required this.doc});

  @override
  Widget build(BuildContext context) {
   
    return Scaffold(
     backgroundColor: Color.fromARGB(255, 240, 235, 235),
      appBar:  AppBar(
            elevation: 0.0,
        backgroundColor: AppColors.blueColor,
        iconTheme: IconThemeData(color: AppColors.white),
     title: AppStyles.bold(
        title: "Doctor's Details",size: AppSizes.size18,color: AppColors.white,
     ),
  ),
  body: Padding(
    padding:   EdgeInsets.all(10.h),
    child: SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: EdgeInsets.all(12.h),
            height: 100.h,
           // padding: EdgeInsets.all(12.h),
           decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(12.h),
             color: AppColors.white,
           ),
           child: 
           Row(
            children: [
              CircleAvatar(
                radius: 40.h,
                child: ClipOval(child: Image.asset("assets/images/doctor1.png")),),
               SizedBox(width: 10.w,),
               Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    AppStyles.bold(
                      title: doc['doc_name'],color: AppColors.textColor,size: AppSizes.size14,
                    ),
                     AppStyles.bold(
                      title: doc['docCategory'],color: AppColors.textColor.withOpacity( 0.5),size: AppSizes.size12,
                      
                    ),
                    Spacer(),
                    VxRating(onRatingUpdate: (value){},
                    selectionColor: Colors.yellow,
                    maxRating: 5,
                    count: 5,
                    value: double.parse(doc['docRatting'].toString()),
                    stepInt: true,)
                  ],
                ),
              
               AppStyles.bold(
                    title: "See All Review",color: AppColors.blueColor.withOpacity( 0.5),size: AppSizes.size12,
                    
                  ),
            ],
           ),
          ),
          SizedBox(height: 10.h,),
          Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12.h),
              color:AppColors.white
            ),
            child: Padding(
              padding: EdgeInsets.all(12.h),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  ListTile(
                    title: AppStyles.bold(title: "Phone Number",color: AppColors.textColor),
                    subtitle: AppStyles.normal(title: doc['docPhone'],color: AppColors.textColor.withOpacity(0.5),
                    size: AppSizes.size12),
                    trailing: Container(
                      width: 50.w,
                      padding: EdgeInsets.all(8.h),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(12.h),
                        color: Colors.yellow
                      ),
                      child: Icon(Icons.phone,color: AppColors.white,),
                    ),
                  ),
                  SizedBox(height: 10.h,),
                  AppStyles.bold(title: "About",color: AppColors.textColor,size: AppSizes.size16),
                  SizedBox(height: 5.h,),
                  AppStyles.normal(title: doc['docAbour'],color: AppColors.textColor.withOpacity(0.5),size: AppSizes.size12),
              
                  SizedBox(height: 10.h,),
                  AppStyles.bold(title: "Adress",color: AppColors.textColor,size: AppSizes.size16),
                  SizedBox(height: 5.h,),
                  AppStyles.normal(title: doc['docAdress'],color: AppColors.textColor.withOpacity(0.5),size: AppSizes.size12),
                    
                  SizedBox(height: 10.h,),
                  AppStyles.bold(title: "Working Time",color: AppColors.textColor,size: AppSizes.size16),
                  SizedBox(height: 5.h,),
                  AppStyles.normal(title: doc['docTiming'],color: AppColors.textColor.withOpacity(0.5),size: AppSizes.size12),
                    
                  SizedBox(height: 10.h,),
                  AppStyles.bold(title: "Services",color: AppColors.textColor,size: AppSizes.size16),
                  SizedBox(height: 5.h,),
                  AppStyles.normal(title: doc['docService'],color: AppColors.textColor.withOpacity(0.5),size: AppSizes.size12),
                ],
              ),
            ),
          )
        ],
      ),
    ),
  ), 
  bottomNavigationBar: Padding(
    padding:  EdgeInsets.all(12.h),
    child: CustomButton(buttonText: "Book an Appointment", onTap: (){
      Get.to(BookAppointment(docId: doc['docId'],docName: doc['doc_name'],));
    }),
  ), 
    );
  }
}