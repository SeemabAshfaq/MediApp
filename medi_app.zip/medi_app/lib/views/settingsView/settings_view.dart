import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:get/get_navigation/get_navigation.dart';
import 'package:medi_app/constants/colors.dart';
import 'package:medi_app/constants/fonts.dart';
import 'package:medi_app/constants/list.dart';
import 'package:medi_app/constants/strings.dart';
import 'package:medi_app/controllers/auth_controller.dart';
import 'package:medi_app/controllers/setting_controller.dart';
import 'package:medi_app/views/loginView/login_view.dart';
import 'package:velocity_x/velocity_x.dart';

class SettingsView extends StatelessWidget {
  const SettingsView({super.key});

  @override
  Widget build(BuildContext context) {
    var controller= Get.put(SettingsController());
    return Scaffold(
  appBar: AppBar(
            elevation: 0.0,
        backgroundColor: AppColors.blueColor,
        iconTheme: IconThemeData(color: AppColors.white),
     title: AppStyles.bold(
        title: AppStrings.settings,size: AppSizes.size18,color: AppColors.white,
     ),
  ),
  body: Obx(()=> controller.isLoading.value?
  const Center(
    child:CircularProgressIndicator()
  ):
     Column(
      children: [
        ListTile(
          leading: CircleAvatar(child: Icon(Icons.person,color: AppColors.blueColor,),),
          title: AppStyles.bold(title: controller.userName.value),
          subtitle: AppStyles.bold(title: controller.email.value),
        ), const Divider(),
      ListView(
        shrinkWrap: true,
    children: List.generate(
      settingsList.length, 
      (index) => ListTile(
        onTap: (){
          if(index==2){
            AuthController().signOut();
            Get.offAll(LoginView());
          }
        },
        leading: Icon(settingsIconsList[index],color: AppColors.blueColor,),
        title: AppStyles.bold(
          title: settingsList[index],
        ),
      ),
    ),
    ) 
      ],
    ),
  ),
    );
  }
}