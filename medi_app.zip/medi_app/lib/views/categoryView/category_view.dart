import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:get/get_navigation/get_navigation.dart';
import 'package:medi_app/constants/colors.dart';
import 'package:medi_app/constants/fonts.dart';
import 'package:medi_app/constants/list.dart';
import 'package:medi_app/constants/strings.dart';
import 'package:medi_app/views/categoryDetailView/category_detail_view.dart';
import 'package:velocity_x/velocity_x.dart';

class CategoryView extends StatelessWidget {
  const CategoryView({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0.0,
        backgroundColor: AppColors.blueColor,
        iconTheme: IconThemeData(color: AppColors.white),
     title: AppStyles.bold(
        title: AppStrings.category,size: AppSizes.size18,color: AppColors.white,
     ),

      ),
     body:Padding(
       padding:  EdgeInsets.all(10.h),
       child: GridView.builder(
        physics: const BouncingScrollPhysics(),
        gridDelegate:const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2,
        mainAxisSpacing: 8,
        crossAxisSpacing: 8,
        mainAxisExtent: 200), 
        itemCount: 6,
        itemBuilder: (BuildContext context, int index ){
          return GestureDetector(
            onTap: (){
              Get.to(()=> CategoryDetailsView(catName: iconsTitleList[index] ,));
            },
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12.h),
                color: AppColors.blueColor,
            
              ),
              child: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    AppStyles.bold(title: iconsTitleList[index],color: AppColors.white,size: AppSizes.size18),
                        AppStyles.bold(title: specialistList[index],color: AppColors.white,size: AppSizes.size16),
                  ],
                ),
              ),
            ),
          );
        }
        
        ),
     )
    );
  }
}