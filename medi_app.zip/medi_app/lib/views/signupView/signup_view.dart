import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:get/get_instance/get_instance.dart';
import 'package:get/get_navigation/get_navigation.dart';
import 'package:medi_app/constants/colors.dart';
import 'package:medi_app/constants/fonts.dart';
import 'package:medi_app/constants/strings.dart';
import 'package:medi_app/controllers/auth_controller.dart';
import 'package:medi_app/views/appointmentView/appointment_view.dart';
import 'package:medi_app/views/homeView/home.dart';
import 'package:medi_app/widgets/custom_button.dart';
import 'package:medi_app/widgets/text_feild.dart';
import 'package:velocity_x/velocity_x.dart';


class SignUpView extends StatefulWidget{
  const SignUpView({super.key});

  @override
  State<SignUpView> createState() => _SignUpViewState();
}

class _SignUpViewState extends State<SignUpView> {
  var isDoctor=false;
  @override
  Widget build(BuildContext context) {
   var controller= Get.put(AuthController());
    return Scaffold(
      body: Container(
        child: 
        Padding(
          padding:  EdgeInsets.all(8.h),
          child: SingleChildScrollView(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  height: 300.h,
                  width: double.infinity,
                  child: 
                Image.asset("assets/images/doctor.jpg",fit: BoxFit.cover,),
                ),
             Form(
                    child:
                 Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.start,
                   children: [
                     SizedBox(height: 20.h,),
                     AppStyles.bold(title: AppStrings.signupNow,size: AppSizes.size18,alignment:TextAlign.center),

                     CustomTextFeild(
                      textController: controller.fullNameController,
                      enteredTextColor: AppColors.textColor,
                      hintColor: AppColors.textColor,
                       textColor: AppColors.textColor,
                    boderColor:  AppColors.textColor,
                      hint: AppStrings.fullanme,
                     ),
                  SizedBox(height: 10.h,),
                     CustomTextFeild(
                      textController: controller.emailController,
                      enteredTextColor: AppColors.textColor,
                       hintColor: AppColors.textColor,
                       textColor: AppColors.textColor,
                    boderColor:  AppColors.textColor,
                      hint: AppStrings.email,
                     ),
                  SizedBox(height: 10.h,),
                      CustomTextFeild(
                        textController: controller.passController,
                        enteredTextColor: AppColors.textColor,
                         hintColor: AppColors.textColor,
                         textColor: AppColors.textColor,
                    boderColor:  AppColors.textColor,
                  hint: AppStrings.password,
                 ),
                  SizedBox(height: 10.h,),
                  SwitchListTile(title: "Signup as a doctor".text.make(), value: isDoctor, onChanged: (newValue){
                    setState(() {
                      isDoctor=newValue;
                    });
                  }),
                     Visibility(
                      visible: isDoctor,
                       child: Column(
                        children: [
                          CustomTextFeild(
                        textController: controller.aboutController,
                        enteredTextColor: AppColors.textColor,
                         hintColor: AppColors.textColor,
                         textColor: AppColors.textColor,
                                           boderColor:  AppColors.textColor,
                        hint: "About",
                       ),
                        SizedBox(height: 10.h,),
                       CustomTextFeild(
                        textController: controller.categoryController,
                        enteredTextColor: AppColors.textColor,
                         hintColor: AppColors.textColor,
                         textColor: AppColors.textColor,
                                           boderColor:  AppColors.textColor,
                        hint: "Category",
                       ),
                        SizedBox(height: 10.h,),
                       CustomTextFeild(
                        textController: controller.serviceController,
                        enteredTextColor: AppColors.textColor,
                         hintColor: AppColors.textColor,
                         textColor: AppColors.textColor,
                                           boderColor:  AppColors.textColor,
                        hint: "Service",
                       ),
                        SizedBox(height: 10.h,),
                       CustomTextFeild(
                        textController: controller.adressController,
                        enteredTextColor: AppColors.textColor,
                         hintColor: AppColors.textColor,
                         textColor: AppColors.textColor,
                                           boderColor:  AppColors.textColor,
                        hint: "Adress",
                       ),
                        SizedBox(height: 10.h,),
                      
                        SizedBox(height: 10.h,),
                       CustomTextFeild(
                        textController: controller.phoneController,
                        enteredTextColor: AppColors.textColor,
                         hintColor: AppColors.textColor,
                         textColor: AppColors.textColor,
                                           boderColor:  AppColors.textColor,
                        hint: "Phone Number",
                       ),
                        SizedBox(height: 10.h,),
                       CustomTextFeild(
                        textController: controller.timingController,
                        enteredTextColor: AppColors.textColor,
                         hintColor: AppColors.textColor,
                         textColor: AppColors.textColor,
                                           boderColor:  AppColors.textColor,
                        hint: "Timing",
                       ),
                        ],
                       ),
                     ),
                 SizedBox(height: 20.h,),
                
                 
            
                 CustomButton(
                  onTap: () async {
                    print("*********");
                    print(isDoctor);
                    await  controller.signupUser(isDoctor);
                    if (controller.userCredential!=null){
                      if(isDoctor){
                        Get.offAll(()=>AppointmentView());
                      }
                      else{
                        Get.offAll(()=>Home());
                      }
                    }


                  },
                  buttonText: AppStrings.signup,
                 ),
            
                 SizedBox(height: 20.h,),
            
                 Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    AppStrings.alreadyHaveAccount.text.make(),
                    SizedBox(width: 8.w,),
                    GestureDetector(
                      onTap: (){
                        Get.back();
                      },
                      child: AppStyles.bold(title:AppStrings.login,alignment: TextAlign.center),
                    )
                  ],
                 )
                   ],
                 ),
            
                 
                  ),
                
              ],
            ),
          ),
        ),
      ),
    );
  }
}