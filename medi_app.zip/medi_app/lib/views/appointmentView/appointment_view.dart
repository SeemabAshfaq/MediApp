import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:get/get_navigation/get_navigation.dart';
import 'package:medi_app/constants/colors.dart';
import 'package:medi_app/constants/fonts.dart';
import 'package:medi_app/constants/strings.dart';
import 'package:medi_app/controllers/appointment_controller.dart';
import 'package:medi_app/controllers/auth_controller.dart';
import 'package:medi_app/views/appointmentDetails/appointment_details.dart';
import 'package:medi_app/views/loginView/login_view.dart';

class AppointmentView extends StatelessWidget {
  final bool isDoctor;
  const AppointmentView({super.key,this.isDoctor=false});

  @override
  Widget build(BuildContext context) {
    var controller= Get.put(AppointmentController());
    return Scaffold(
      appBar: AppBar(
  elevation: 0.0,
  backgroundColor: AppColors.blueColor,
  iconTheme: IconThemeData(color: AppColors.white),
  title: Row( mainAxisAlignment: MainAxisAlignment.spaceBetween,
    children: [
      AppStyles.bold(
        title: "Appointments",
        size: AppSizes.size18,
        color: AppColors.white,
      ),
     IconButton(onPressed: (){
      AuthController().signOut();
            Get.offAll(LoginView());
     }, icon:  Icon(
        Icons.logout, // Icon you want to add
        color: AppColors.white,
      ),)
    ],
  ),
),

      body: FutureBuilder(future: controller.getAppointments(isDoctor),
       builder: (BuildContext context,AsyncSnapshot<QuerySnapshot> snapshot){
        if(!snapshot.hasData){
         return Center(
          child: CircularProgressIndicator(),
         );
        }
        else{
          var data= snapshot.data!.docs;
         return Padding(
        padding:  EdgeInsets.all(12.h),
        child: ListView.builder(
          
          itemCount: data.length??0,
          itemBuilder: (BuildContext context, int index){
          return ListTile(
            onTap: (){
              Get.to( ()=>AppointmentDetailsView(
                doc: data[index],
              ));
            },
           leading:  CircleAvatar(child: Image.asset("assets/images/doctor1.png"),
           ),
           title: AppStyles.bold(title: data[index][isDoctor?'appWithName':'appName']),
           subtitle: AppStyles.normal(title: "${data[index]['appDay']}- ${data[index]['appTime']}",color:AppColors.textColor),
          );
        }),
      );
        }
       })
    );
  }
}